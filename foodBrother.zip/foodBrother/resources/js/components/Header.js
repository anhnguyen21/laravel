import React, { Component } from 'react';

class Header extends Component {
    render() {
        return (
            <div>
                this header
            </div>
        );
    }
}

export default Header;