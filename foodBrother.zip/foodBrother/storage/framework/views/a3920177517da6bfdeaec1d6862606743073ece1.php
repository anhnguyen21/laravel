<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mail</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p><?php echo e($details['body']); ?></p>
    <p>Thank you</p>
</body>
</html><?php /**PATH C:\xampp\htdocs\foodBrother\resources\views/mail.blade.php ENDPATH**/ ?>